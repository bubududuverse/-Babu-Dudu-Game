/* ============================================================
   BUBU A BUBUDUDU — sprites.js
   Asset loading with progress + hand-drawn canvas fallbacks
   (game still runs if the PNGs are missing)
   ============================================================ */
window.Sprites = (function () {
  'use strict';

  const S = {
    ready: false,
    assets: {},
    list: [
      { id: 'bubu', url: 'assets/images/bubu.png' },
      { id: 'dudu', url: 'assets/images/dudu.png' },
    ],
  };

  S.load = function (onProgress) {
    let done = 0;
    const total = S.list.length || 1;
    return new Promise((resolve) => {
      if (!S.list.length) { S.ready = true; onProgress && onProgress(1); return resolve(); }
      S.list.forEach((item) => {
        const img = new Image();
        const finish = (ok) => {
          S.assets[item.id] = { img, ok };
          done++;
          onProgress && onProgress(done / total);
          if (done >= total) { S.ready = true; resolve(); }
        };
        img.onload = () => finish(true);
        img.onerror = () => finish(false);
        img.src = item.url;
      });
    });
  };

  S.get = (id) => {
    const a = S.assets[id];
    return a && a.ok ? a.img : null;
  };

  /* draw a character (image if available, fallback art otherwise)
     x,y = top-left, w,h = box */
  S.draw = function (ctx, id, x, y, w, h) {
    const img = S.get(id);
    if (img) { ctx.drawImage(img, x, y, w, h); return; }
    ctx.save();
    ctx.translate(x, y);
    ctx.scale(w / 100, h / 100);
    (id === 'bubu' ? drawBubuFallback : drawDuduFallback)(ctx);
    ctx.restore();
  };

  /* ---------- fallback: Bubu the panda ---------- */
  function drawBubuFallback(ctx) {
    // ears
    ctx.fillStyle = '#3a241c';
    ctx.beginPath(); ctx.arc(28, 16, 12, 0, 7); ctx.fill();
    ctx.beginPath(); ctx.arc(72, 16, 12, 0, 7); ctx.fill();
    // bow
    ctx.fillStyle = '#ff8fab';
    ctx.beginPath(); ctx.arc(66, 10, 7, 0, 7); ctx.fill();
    ctx.beginPath(); ctx.arc(78, 10, 7, 0, 7); ctx.fill();
    ctx.fillStyle = '#e56a8c';
    ctx.beginPath(); ctx.arc(72, 11, 4, 0, 7); ctx.fill();
    // head + body
    ctx.fillStyle = '#ffffff';
    ctx.strokeStyle = '#3a241c'; ctx.lineWidth = 4;
    ctx.beginPath(); ctx.ellipse(50, 34, 34, 30, 0, 0, 7); ctx.fill(); ctx.stroke();
    ctx.beginPath(); ctx.ellipse(50, 76, 26, 22, 0, 0, 7); ctx.fill(); ctx.stroke();
    // blush
    ctx.fillStyle = 'rgba(255,143,171,0.75)';
    ctx.beginPath(); ctx.arc(30, 42, 7, 0, 7); ctx.fill();
    ctx.beginPath(); ctx.arc(70, 42, 7, 0, 7); ctx.fill();
    // eyes + mouth
    ctx.fillStyle = '#3a241c';
    ctx.beginPath(); ctx.arc(38, 34, 4.5, 0, 7); ctx.fill();
    ctx.beginPath(); ctx.arc(62, 34, 4.5, 0, 7); ctx.fill();
    ctx.strokeStyle = '#3a241c'; ctx.lineWidth = 2.5;
    ctx.beginPath(); ctx.arc(46, 40, 4, 0.2, Math.PI - 0.2); ctx.stroke();
    ctx.beginPath(); ctx.arc(54, 40, 4, 0.2, Math.PI - 0.2); ctx.stroke();
    // feet
    ctx.fillStyle = '#3a241c';
    ctx.beginPath(); ctx.ellipse(38, 96, 9, 5, 0, 0, 7); ctx.fill();
    ctx.beginPath(); ctx.ellipse(62, 96, 9, 5, 0, 0, 7); ctx.fill();
  }

  /* ---------- fallback: Dudu the bear ---------- */
  function drawDuduFallback(ctx) {
    // ears
    ctx.fillStyle = '#8a5a3b';
    ctx.strokeStyle = '#4a2c1a'; ctx.lineWidth = 4;
    ctx.beginPath(); ctx.arc(28, 16, 11, 0, 7); ctx.fill(); ctx.stroke();
    ctx.beginPath(); ctx.arc(72, 16, 11, 0, 7); ctx.fill(); ctx.stroke();
    ctx.fillStyle = '#5d3a24';
    ctx.beginPath(); ctx.arc(28, 16, 5, 0, 7); ctx.fill();
    ctx.beginPath(); ctx.arc(72, 16, 5, 0, 7); ctx.fill();
    // head + body
    ctx.fillStyle = '#c08552';
    ctx.strokeStyle = '#4a2c1a';
    ctx.beginPath(); ctx.ellipse(50, 36, 34, 31, 0, 0, 7); ctx.fill(); ctx.stroke();
    ctx.beginPath(); ctx.ellipse(50, 78, 27, 22, 0, 0, 7); ctx.fill(); ctx.stroke();
    // blush glow
    ctx.fillStyle = 'rgba(255,209,102,0.8)';
    ctx.beginPath(); ctx.arc(28, 44, 7, 0, 7); ctx.fill();
    ctx.beginPath(); ctx.arc(72, 44, 7, 0, 7); ctx.fill();
    // eyes + mouth
    ctx.fillStyle = '#33201a';
    ctx.beginPath(); ctx.arc(38, 36, 4.5, 0, 7); ctx.fill();
    ctx.beginPath(); ctx.arc(62, 36, 4.5, 0, 7); ctx.fill();
    ctx.strokeStyle = '#33201a'; ctx.lineWidth = 2.5;
    ctx.beginPath(); ctx.arc(46, 42, 4, 0.2, Math.PI - 0.2); ctx.stroke();
    ctx.beginPath(); ctx.arc(54, 42, 4, 0.2, Math.PI - 0.2); ctx.stroke();
    // feet
    ctx.fillStyle = '#4a2c1a';
    ctx.beginPath(); ctx.ellipse(38, 97, 9, 5, 0, 0, 7); ctx.fill();
    ctx.beginPath(); ctx.ellipse(62, 97, 9, 5, 0, 0, 7); ctx.fill();
  }

  return S;
})();

/* scripts load game.js → engine.js → sprites.js, so everything
   exists by the time this last file runs */
window.addEventListener('DOMContentLoaded', function () {
  if (window.Game && window.Engine && window.Sprites) window.Game.boot();
});
