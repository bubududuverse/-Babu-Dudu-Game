/* ============================================================
   BUBU A BUBUDUDU — engine.js
   Tiny self-contained game engine:
   Canvas scaler · Input (keyboard + touch) · Chiptune audio
   Fixed-ish game loop · Particle system
   ============================================================ */
window.Engine = (function () {
  'use strict';

  const E = {};
  E.TAU = Math.PI * 2;

  /* ---------------- math utils ---------------- */
  E.clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  E.lerp = (a, b, t) => a + (b - a) * t;
  E.rand = (a, b) => a + Math.random() * (b - a);
  E.randInt = (a, b) => Math.floor(E.rand(a, b + 1));
  E.choice = (arr) => arr[(Math.random() * arr.length) | 0];
  E.aabb = (a, b) =>
    a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y;
  // deterministic hash -> [0,1)  (for stable world-locked scenery)
  E.hash = (n) => {
    let x = Math.sin(n * 127.1) * 43758.5453;
    return x - Math.floor(x);
  };

  /* ---------------- canvas ---------------- */
  E.Canvas = {
    W: 960, H: 540,          // logical resolution
    el: null, ctx: null,
    sx: 1, sy: 1,
    init(el) {
      this.el = el;
      this.ctx = el.getContext('2d');
      this.resize();
      window.addEventListener('resize', () => this.resize());
      if (window.visualViewport)
        window.visualViewport.addEventListener('resize', () => this.resize());
    },
    resize() {
      const r = this.el.getBoundingClientRect();
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const w = Math.max(1, Math.round((r.width || this.W) * dpr));
      const h = Math.max(1, Math.round((r.height || this.H) * dpr));
      if (this.el.width !== w || this.el.height !== h) {
        this.el.width = w; this.el.height = h;
      }
      this.sx = this.el.width / this.W;
      this.sy = this.el.height / this.H;
    },
    begin() { this.ctx.setTransform(this.sx, 0, 0, this.sy, 0, 0); },
  };

  /* ---------------- input ---------------- */
  const CODES = new Set([
    'ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown',
    'Space', 'KeyA', 'KeyD', 'KeyW', 'KeyS', 'KeyP', 'Escape',
  ]);

  E.Input = {
    keys: Object.create(null),
    pressedActs: Object.create(null),
    touch: { left: false, right: false, crouch: false },
    init() {
      window.addEventListener('keydown', (e) => {
        if (CODES.has(e.code)) e.preventDefault();
        if (!e.repeat) {
          const a = this._actOf(e.code);
          if (a) this.pressedActs[a] = true;
        }
        this.keys[e.code] = true;
        E.Audio.unlock();
      });
      window.addEventListener('keyup', (e) => { this.keys[e.code] = false; });
      window.addEventListener('blur', () => {
        this.keys = Object.create(null);
        this.touch.left = this.touch.right = this.touch.crouch = false;
      });
    },
    _actOf(code) {
      switch (code) {
        case 'ArrowLeft': case 'KeyA': return 'left';
        case 'ArrowRight': case 'KeyD': return 'right';
        case 'ArrowUp': case 'KeyW': case 'Space': return 'jump';
        case 'ArrowDown': case 'KeyS': return 'crouch';
        default: return null;
      }
    },
    down(a) {
      switch (a) {
        case 'left':   return !!this.keys.ArrowLeft || !!this.keys.KeyA || this.touch.left;
        case 'right':  return !!this.keys.ArrowRight || !!this.keys.KeyD || this.touch.right;
        case 'jump':   return !!this.keys.ArrowUp || !!this.keys.KeyW || !!this.keys.Space;
        case 'crouch': return !!this.keys.ArrowDown || !!this.keys.KeyS || this.touch.crouch;
      }
      return false;
    },
    hit(a) { return !!this.pressedActs[a]; },
    queue(a) { this.pressedActs[a] = true; },
    endFrame() { this.pressedActs = Object.create(null); },
  };

  /* ---------------- audio (webaudio chiptune) ---------------- */
  E.Audio = {
    ctx: null, master: null, musicGain: null,
    muted: false, _step: 0, _next: 0, _timer: null, _musicOn: false,
    unlock() {
      if (!this.ctx) {
        const AC = window.AudioContext || window.webkitAudioContext;
        if (!AC) return;
        try {
          this.ctx = new AC();
          this.master = this.ctx.createGain();
          this.master.gain.value = 0.5;
          this.master.connect(this.ctx.destination);
          this.musicGain = this.ctx.createGain();
          this.musicGain.gain.value = 0.13;
          this.musicGain.connect(this.master);
        } catch (e) { this.ctx = null; }
      }
      if (this.ctx && this.ctx.state === 'suspended') this.ctx.resume();
    },
    tone(o) {
      if (!this.ctx || this.muted) return;
      const {
        freq = 440, end = 0, dur = 0.15, type = 'square',
        vol = 0.3, when = 0, dest = null,
      } = o;
      const t = this.ctx.currentTime + when;
      const osc = this.ctx.createOscillator();
      const g = this.ctx.createGain();
      osc.type = type;
      osc.frequency.setValueAtTime(Math.max(30, freq), t);
      osc.frequency.exponentialRampToValueAtTime(Math.max(30, end || freq), t + dur);
      g.gain.setValueAtTime(0.0001, t);
      g.gain.linearRampToValueAtTime(vol, t + 0.012);
      g.gain.exponentialRampToValueAtTime(0.001, t + dur);
      osc.connect(g); g.connect(dest || this.master);
      osc.start(t); osc.stop(t + dur + 0.05);
    },
    noise(o) {
      if (!this.ctx || this.muted) return;
      const { dur = 0.2, vol = 0.3, when = 0, cutoff = 900 } = o;
      const t = this.ctx.currentTime + when;
      const len = Math.max(1, (this.ctx.sampleRate * dur) | 0);
      const buf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
      const d = buf.getChannelData(0);
      for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / len);
      const src = this.ctx.createBufferSource();
      src.buffer = buf;
      const f = this.ctx.createBiquadFilter();
      f.type = 'lowpass'; f.frequency.value = cutoff;
      const g = this.ctx.createGain(); g.gain.value = vol;
      src.connect(f); f.connect(g); g.connect(this.master);
      src.start(t);
    },
    sfx: {
      click()   { E.Audio.tone({ freq: 620, end: 900, dur: 0.07, type: 'square', vol: 0.22 }); },
      jump()    { E.Audio.tone({ freq: 300, end: 720, dur: 0.16, type: 'square', vol: 0.25 }); },
      land()    { E.Audio.noise({ dur: 0.08, vol: 0.12, cutoff: 500 }); },
      collect() {
        E.Audio.tone({ freq: 880, dur: 0.08, type: 'triangle', vol: 0.3 });
        E.Audio.tone({ freq: 1318, dur: 0.12, type: 'triangle', vol: 0.26, when: 0.07 });
      },
      hit()     {
        E.Audio.noise({ dur: 0.25, vol: 0.4, cutoff: 700 });
        E.Audio.tone({ freq: 220, end: 60, dur: 0.3, type: 'sawtooth', vol: 0.3 });
      },
      level()   {
        [523, 659, 784, 1046].forEach((f, i) =>
          E.Audio.tone({ freq: f, dur: 0.14, type: 'square', vol: 0.25, when: i * 0.09 }));
      },
      over()    {
        [392, 330, 262, 196].forEach((f, i) =>
          E.Audio.tone({ freq: f, dur: 0.22, type: 'triangle', vol: 0.3, when: i * 0.16 }));
      },
    },
    /* pentatonic jog through the bamboo grove */
    startMusic() {
      this.unlock();
      if (!this.ctx || this._musicOn) return;
      this._musicOn = true;
      this._step = 0;
      this._next = this.ctx.currentTime + 0.1;
      const bass = [110, 0, 82.4, 0, 98, 0, 65.4, 0, 110, 0, 82.4, 0, 98, 0, 73.4, 0];
      const mel = [440, 523.3, 587.3, 659.3, 784, 659.3, 587.3, 523.3];
      this._timer = setInterval(() => {
        if (!this.ctx || !this._musicOn) return;
        while (this._next < this.ctx.currentTime + 0.25) {
          const s = this._step % 16;
          const when = this._next - this.ctx.currentTime;
          const b = bass[s];
          if (b) this.tone({ freq: b, dur: 0.22, type: 'sine', vol: 0.5, when, dest: this.musicGain });
          if (s % 2 === 0 && Math.random() < 0.62) {
            const m = mel[(Math.random() * mel.length) | 0];
            this.tone({ freq: m, dur: 0.16, type: 'triangle', vol: 0.34, when, dest: this.musicGain });
          }
          if (s % 4 === 2) this.noise({ dur: 0.05, vol: 0.05, when, cutoff: 4000 });
          this._next += 0.14;
          this._step++;
        }
      }, 90);
    },
    stopMusic() {
      this._musicOn = false;
      if (this._timer) { clearInterval(this._timer); this._timer = null; }
    },
  };

  /* ---------------- main loop ---------------- */
  E.Loop = {
    raf: 0, last: 0, running: false,
    update: null, render: null,
    start(update, render) {
      this.update = update; this.render = render;
      if (this.running) return;
      this.running = true;
      this.last = performance.now();
      const tick = (t) => {
        if (!this.running) return;
        const dt = Math.min(0.05, (t - this.last) / 1000);
        this.last = t;
        this.update(dt);
        this.render();
        E.Input.endFrame();
        this.raf = requestAnimationFrame(tick);
      };
      this.raf = requestAnimationFrame(tick);
    },
    stop() { this.running = false; cancelAnimationFrame(this.raf); },
  };

  /* ---------------- particles ---------------- */
  E.Particles = {
    list: [],
    clear() { this.list.length = 0; },
    spawn(p) {
      this.list.push(Object.assign({
        x: 0, y: 0, vx: 0, vy: 0, g: 0, life: 0.6, max: 0.6,
        size: 4, color: '#fff', shape: 'circle', rot: 0, vr: 0, text: '',
      }, p));
    },
    dust(x, y, n = 6) {
      for (let i = 0; i < n; i++)
        this.spawn({
          x: x + E.rand(-10, 10), y: y + E.rand(-4, 2),
          vx: E.rand(-70, 70), vy: E.rand(-90, -20), g: 260,
          life: E.rand(0.3, 0.55), size: E.rand(3, 7),
          color: 'rgba(214,236,190,0.9)',
        });
    },
    sparkle(x, y, color = '#ffd166', n = 10) {
      for (let i = 0; i < n; i++) {
        const a = E.rand(0, E.TAU), sp = E.rand(60, 220);
        this.spawn({
          x, y, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp - 60, g: 320,
          life: E.rand(0.35, 0.7), size: E.rand(3, 6), color, shape: 'star',
          rot: E.rand(0, E.TAU), vr: E.rand(-6, 6),
        });
      }
    },
    poof(x, y, n = 14) {
      for (let i = 0; i < n; i++) {
        const a = E.rand(0, E.TAU), sp = E.rand(40, 190);
        this.spawn({
          x, y, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp, g: 140,
          life: E.rand(0.3, 0.6), size: E.rand(6, 14),
          color: 'rgba(255,246,224,0.85)',
        });
      }
    },
    /* the couple's signature: floating hearts */
    hearts(x, y, n = 10) {
      for (let i = 0; i < n; i++)
        this.spawn({
          x: x + E.rand(-14, 14), y: y + E.rand(-10, 10),
          vx: E.rand(-50, 50), vy: E.rand(-150, -60), g: -30,
          life: E.rand(0.6, 1.0), size: E.rand(5, 9),
          color: E.choice(['#ff8fab', '#e4572e', '#ffd7e0']),
          shape: 'heart', rot: E.rand(-0.4, 0.4),
        });
    },
    text(x, y, text, color = '#ffd166') {
      this.spawn({ x, y, vy: -70, life: 0.9, max: 0.9, text, color, shape: 'text', size: 20 });
    },
    update(dt) {
      const L = this.list;
      for (let i = L.length - 1; i >= 0; i--) {
        const p = L[i];
        p.life -= dt;
        if (p.life <= 0) { L.splice(i, 1); continue; }
        p.vy += p.g * dt;
        p.x += p.vx * dt;
        p.y += p.vy * dt;
        p.rot += p.vr * dt;
      }
    },
    render(ctx) {
      for (const p of this.list) {
        const a = E.clamp(p.life / p.max, 0, 1);
        ctx.save();
        ctx.globalAlpha = a;
        ctx.translate(p.x, p.y);
        if (p.shape === 'text') {
          ctx.font = p.size + "px 'Press Start 2P', monospace";
          ctx.textAlign = 'center';
          ctx.lineWidth = 4;
          ctx.strokeStyle = 'rgba(45,27,18,0.9)';
          ctx.strokeText(p.text, 0, 0);
          ctx.fillStyle = p.color;
          ctx.fillText(p.text, 0, 0);
        } else if (p.shape === 'heart') {
          ctx.rotate(p.rot);
          ctx.fillStyle = p.color;
          const s = p.size;
          ctx.beginPath();
          ctx.moveTo(0, s * 0.8);
          ctx.bezierCurveTo(-s * 1.1, -s * 0.2, -s * 0.6, -s * 1.05, 0, -s * 0.35);
          ctx.bezierCurveTo(s * 0.6, -s * 1.05, s * 1.1, -s * 0.2, 0, s * 0.8);
          ctx.fill();
        } else if (p.shape === 'star') {
          ctx.rotate(p.rot);
          ctx.fillStyle = p.color;
          const s = p.size;
          ctx.beginPath();
          for (let i = 0; i < 4; i++) {
            ctx.lineTo(0, -s); ctx.lineTo(s * 0.32, -s * 0.32);
            ctx.rotate(Math.PI / 2);
          }
          ctx.closePath(); ctx.fill();
        } else {
          ctx.fillStyle = p.color;
          ctx.beginPath();
          ctx.arc(0, 0, p.size * (0.5 + a * 0.5), 0, E.TAU);
          ctx.fill();
        }
        ctx.restore();
      }
    },
  };

  return E;
})();
