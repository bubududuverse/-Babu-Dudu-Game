# 🎮 BUBU A BUBUDUDU — Games ko online karke fans se share karna

Do games ready hain:
- **index.html** → Runner game (endless bamboo run)
- **tag.html** → TAG Mode (2-player / vs CPU pakdam-pakai)

Dono **pure static files** hain — koi server / database nahi chahiye.
Isliye kisi bhi free static host par 2 minute mein live ho jaate hain.

> ⚠️ Note: Arena/sandbox ka preview link **temporary** hota hai — fans ko wo link mat bhejo.
> Neeche wale hosts ka link permanent free hai.

---

## 🥇 Option A — Netlify Drop (sabse aasan, ~2 minute, bina code)

1. Browser mein kholo: **https://app.netlify.com/drop**
2. Account banao (Google/GitHub/email se — free).
3. `bubu-dudu-games.zip` **unzip** karo aur pura folder drag karke page par drop kar do
   (zip bhi directly drop kar sakte ho).
4. Turant live link mil jaayega, jaise `random-name.netlify.app`
5. Site settings → "Change site name" → apna naam rakho, jaise
   **`bubu-a-bubududu.netlify.app`** ✅
6. Yeh link fans ko bhejo — WhatsApp, Instagram bio, Twitter, kahin bhi.

---

## 🥈 Option B — itch.io (gamers wali jagah, donations bhi yahan)

1. **https://itch.io** par free account banao (naam rakho `tender-duo` jo bhi available ho).
2. Dashboard → **"Upload new project"**
3. Settings:
   - Kind: **HTML**
   - Zip upload karo: `bubu-dudu-games.zip`
   - Tick: **"This file will be played in the browser"**
   - Default file: `index.html`
4. Page description mein apna **buymeacoffee.com/tender.duo** link chipkao
   (itch par "donations" ka option bhi hota hai — extra kamai!).
5. Publish → link banega `tender-duo.itch.io/bubu-a-bubududu` — fans browser mein
   seedha khelenge, download ki zaroorat nahi.

---

## 🥉 Option C — GitHub Pages (free, apna repo)

1. github.com par account → New repository `bubu-a-bubududu`
2. Zip ke **andar ki saari files** (index.html, tag.html, style.css, tag.css, js/, assets/)
   repo mein upload karo (root par, folder ke andar nahi).
3. Settings → Pages → Branch: `main` / root → Save
4. Link: `https://<username>.github.io/bubu-a-bubududu/`

---

## 📣 Fans tak pahunchana

- **WhatsApp/Telegram:** live link + ek chhota video/GIF gameplay ka.
- **Instagram bio:** link field mein game ka link (`linktr.ee` use karte ho to wahan bhi).
- **BuyMeACoffee page:** post banao "Hamara game khelo!" + link — supporters wahin hote hain jo khelenge bhi aur coffee bhi pilayenge ☕
- **QR code:** live link milne ke baad bolo — main turant QR image bana dunga jo
  posters/stories par chipka sakte ho.

---

## 📦 Offline / direct khelna (bina internet)

Zip unzip karo → `index.html` par double-click → browser mein chal jaayega.
(Internet sirf Google Fonts ke liye chahiye; bina net ke game chalta hai,
bas font simple dikhega.)

---

## 🔧 Baad mein upgrade (jab bolo, main bana dunga)

- "Share your score" button (Web Share API) — score ke saath link fans ko bhejne wala
- Live link ka **QR code**
- Custom domain (jaise `play.tenderduo.com`) jodne mein madad
- Teesra game: Flappy-Together ya Bamboo Rain 💞
