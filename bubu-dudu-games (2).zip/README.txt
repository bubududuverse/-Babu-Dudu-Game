BUBU A BUBUDUDU — GAME PACK  💞
================================
Games (browser mein khelo):
  index.html  -> Runner: bamboo collect karo, Dudu ke hugs se bacho
  tag.html    -> TAG Mode: 2 players ek keyboard par, ya solo vs CPU

Offline khelna: unzip karo, index.html double-click karo. Bas!
Online share karna: SHARE-GUIDE.md padho (Netlify Drop / itch.io / GitHub Pages).

Made with love by the couple -> https://buymeacoffee.com/tender.duo
